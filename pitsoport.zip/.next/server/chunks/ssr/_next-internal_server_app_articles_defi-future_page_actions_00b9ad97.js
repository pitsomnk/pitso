module.exports=[45036,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_articles_defi-future_page_actions_00b9ad97.js.map