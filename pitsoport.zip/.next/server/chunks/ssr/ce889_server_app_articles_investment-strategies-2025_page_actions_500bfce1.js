module.exports=[62677,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_articles_investment-strategies-2025_page_actions_500bfce1.js.map